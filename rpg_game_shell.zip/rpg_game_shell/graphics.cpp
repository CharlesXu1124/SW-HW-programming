#include "graphics.h"
#include "globals.h"

void draw_player(int u, int v, int key)
{
    uLCD.filled_rectangle(u-5, v-5, u+10, v+10, BLACK);
    uLCD.filled_circle(u, v+5, 3, 0xFFFF00);
    uLCD.triangle(u-5, v+3, u, v+5, u+10, v+5, BLUE);
    uLCD.triangle(u-5, v+7, u, v+5, u+10, v+5, BLUE);
    uLCD.triangle(u, v, u, v+5, u+2, v+5, BLUE);
    uLCD.triangle(u, v+10, u, v+5, u+2, v+5, BLUE);
}

void draw_player_UP(int u, int v, int key)
{
    uLCD.filled_rectangle(u-5, v-5, u+10, v+10, BLACK);
    uLCD.filled_circle(u, v+5, 3, 0xFFFF00);
    uLCD.triangle(u-3, v+7, u+3, v+7, u, v+5, BLUE);
    uLCD.triangle(u, v-5, u+3, v+10, u, v+7, BLUE);
    uLCD.triangle(u, v-5, u-3, v+10, u, v+7, BLUE);
}

void draw_player_DOWN(int u, int v, int key)
{
    uLCD.filled_rectangle(u-5, v-5, u+10, v+10, BLACK);
    uLCD.filled_circle(u, v+5, 3, 0xFFFF00);
    uLCD.triangle(u, v+10, u-3, v, u, v+3, BLUE);
    uLCD.triangle(u, v+10, u+3, v, u, v+3, BLUE);
    uLCD.triangle(u-5, v, u+5, v, u, v+3, BLUE);
}

void draw_player_LEFT(int u, int v, int key)
{
    uLCD.filled_rectangle(u-10, v-10, u+10, v+10, BLACK);
    uLCD.filled_circle(u, v+5, 3, 0xFFFF00);
    uLCD.triangle(u+10, v, u-10, v+5, u+7, v+5, BLUE);
    uLCD.triangle(u+10, v+10, u-10, v+5, u+7, v+5, BLUE);
    uLCD.triangle(u, v, u, v+10, u-2, v+5, BLUE);
}

#define YELLOW      0xFFFF00
#define BROWN       0xD2691E
#define DIRT        0x000000
#define GOLD        0xF5B536

void draw_img(int u, int v, const char* img)
{
    int colors[11*11];
    for (int i = 0; i < 11*11; i++) {
        if (img[i] == 'R') colors[i] = RED;
        else if (img[i] == 'Y') colors[i] = YELLOW;
        else if (img[i] == 'G') colors[i] = GOLD;
        else if (img[i] == 'D') colors[i] = DIRT;
        else if (img[i] == '5') colors[i] = LGREY;
        else if (img[i] == '3') colors[i] = DGREY;
        else if (img[i] == 'R') colors[i] = RED;
        else if (img[i] == 'K') colors[i] = BLACK;
        else if (img[i] == 'W') colors[i] = WHITE;

        //hamburger
        else if (img[i] == 'S') colors[i] = BACKGROUND;
        else if (img[i] == '1') colors[i] = 0xE5B149;
        else if (img[i] == '2') colors[i] = 0x2EFF1F;
        else if (img[i] == 'T') colors[i] = RED;
        else if (img[i] == 'C') colors[i] = 0xFFC400;
        else if (img[i] == 'M') colors[i] = 0x552F0D;

        //fry guy and 0xC6C3BE babies
        else if (img[i] == 'B') colors[i] = 0x0112FF;
        else if (img[i] == '6') colors[i] = 0xFFE2A0;
        else if (img[i] == '7') colors[i] = 0x7C4F31;
        else if (img[i] == '8') colors[i] = 0xC6C3BE;
        else if (img[i] == '9') colors[i] = 0xE12EDB;
        else if (img[i] == '5') colors[i] = 0xB9B2D1;
        else if (img[i] == 'U') colors[i] = 0x00FFDE;

        else colors[i] = BLACK;
    }
    uLCD.BLIT(u, v, 11, 11, colors);
    wait_us(250); // Recovery time!
}

void draw_nothing(int u, int v)
{
    // Fill a tile with blackness
    uLCD.filled_rectangle(u, v, u+10, v+10, BLACK);
}


void draw_plant(int u, int v)
{
    uLCD.filled_rectangle(u, v, u+10, v+10, GREEN);
}

void draw_upper_status(int x, int y, int burgerCount, int burgerToggle)
{


    //rectangle and border
    uLCD.filled_rectangle(0,8,127,0,0xB9B2D1);
    uLCD.line(0, 8, 128, 8, RED);



    uLCD.textbackground_color(0xB9B2D1);
    uLCD.color(0xFF0000);

//add player coordinates
    uLCD.locate(1,0);
    uLCD.printf("(%d,",x);
    uLCD.color(0x0D3572);
    uLCD.locate(6,0);
    uLCD.printf("%d)",y);

}



void draw_lower_status(int MissileCount, int quest,int babyCount)
{
    uLCD.filled_rectangle(0,128,127,118,0xD3E671);
    // Draw top border of status bar
    uLCD.line(0, 118, 128, 118, RED);

    // Add other status info drawing code here

    uLCD.textbackground_color(0xC5BB44);
    uLCD.locate(0,15);
    uLCD.color(BLACK);
    uLCD.printf("Missile: %d/5", MissileCount);
    uLCD.filled_circle(120,121,3,0xC544BD);
}

void draw_border()
{
    uLCD.filled_rectangle(0,     9, 127,  14, BLACK); // Top
    uLCD.filled_rectangle(0,    13,   2, 114, BLACK); // Left
    uLCD.filled_rectangle(0,   114, 127, 117, BLACK); // Bottom
    uLCD.filled_rectangle(124,  14, 127, 117, BLACK); // Right
}





void draw_citizen(int u, int v)

{
    uLCD.triangle(u+5, v, u, v+10, u+10, v+10, RED);
}

void draw_survivor(int u, int v)
{
    char fryguy[122] = "GGGGGSCKKKTCCCSCSCCCGGGGGCCCCCTTSTCCCCCCCTSSTT5KT5KTGGGTTGGGGGGGGTTBTTTTTBTTSTTBBBBBTTSSTTTTTTTTTSSSTTSSSTTSSSTTSSSSSTTS";
    draw_img(u,v,fryguy);
}

void draw_block(int u, int v)
{
    char block[122] = "KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK";
    draw_img(u,v,block);
}

void draw_fuel(int u, int v)

{
    char fuel[122] = "SSSSSBBBBBSSSSSSBSSSBSSSSWWWWWSSSSSKTTTTTKSSSSKTUUUTKSSSSKTUTTTKSSSSKTUUUTKSSSSKTTTUTKSSSSKTUUUTKSSSSKTTTTTKSSSSKKKKKKKSS";
    draw_img(u,v,fuel);
}

void draw_block2(int u, int v)
{
    char block2[122] = "KKKKKKKKKKKKKKKKKKKKKKYYYYKKKKKKKKKYYYYYYYKKKKGWWWWGGKKKKGGGGGGGKKKKBBGYYYYKKKKGGGGGGGKKKKKKKKKKKKKKKBBBBKKKKKKKKKKKKKKKK";
    draw_img(u,v,block2);
}

void draw_meteor(int u, int v)

{
    uLCD.filled_circle(u+5, v+5, 5, 0xC5BB44);
}

void draw_creature1(int u, int v)

{
    uLCD.filled_circle(u, v, 5, 0xB036A7);
    uLCD.triangle(u, v+5, u+5, v+10, u-5, v+10, BLUE);
}

void draw_creature2(int u, int v)

{
    uLCD.filled_circle(u, v, 5, 0xB036A7);
    uLCD.triangle(u, v+5, u+5, v+10, u-5, v+10, RED);
}
