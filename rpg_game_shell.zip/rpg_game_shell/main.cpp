// Project includes
#include "globals.h"
#include "hardware.h"
#include "map.h"
#include "graphics.h"
#include "speech.h"
#include "emic2.h"
int weapon_pressed = 0;
int speechTog =  0;
int startScreen = 1;
emic2 myTTS(p13, p14);


int METEORSwitch = 0; // when you're done with METEORs
int questSwitch = 0; // to be able to be told what to do with the METEORs
int creatureSwitch = 0; // to be able to feed babies
int narratorSwitch = 0;
int FUELSwitch = 0;

GameInputs in;
int action;
int update;

// Functions in this file
int get_action (GameInputs inputs);
int update_game (int action);
void draw_game (int init);
void init_main_map ();
void init_second_map();
int main ();

//my added functions
int fire(int x, int y);
int go_right(int x, int y);
int go_left(int x, int y);
int go_up(int x, int y);
int go_down(int x, int y);

int get_surrounding_object(int x, int y);
void draw_intro();

/**
 * The main game state. Must include Player locations and previous locations for
 * drawing to work properly. Other items can be added as needed.
 */
struct {
    int x,y;    // Current locations
    int px, py; // Previous locations
    int has_key;
    int METEORCount;
    int prevMETEORCount;
    int creatureCount;
    int prevcreatureCount;
} Player;

/**
 * Given the game inputs, determine what kind of update needs to happen.
 * Possbile return values are defined below.
 */
#define NO_ACTION 0
#define ACTION_BUTTON 1
#define MENU_BUTTON 2
#define FIRE 8
#define GO_LEFT 3
#define GO_RIGHT 4
#define GO_UP 5
#define GO_DOWN 6
#define END_GAME 7


char *lineStartQuest = "Warrior from the mighty Earth!" \
                       "We deperately need you!"\
                       "This way on board! You are introduced to the latest starfighter! F-302"\
                       "From now on I will become your AI assistant";

char *narrator1   = "F-302 is the human's last hope";

char *Details = "Main weapon: 2 rail guns, 20 missiles." \
                  "The F-302 can perform tactical jump thanks to its warp engine powered by neutrino generator.";

char *Details2 = "Stop resisting you pitious earthy worm!";

char *questSection2 = "Keep fighting warrior, our galaxy depends on you!" \
                   "Wait! Bionic weapons detected."\
                   "Destroy bionic targets.";


char *questSection3 = "They are so disgusting...They used captured citizens to perform biological experiment." \
                   "wait, seems their fleet is nearby!";

char *creaturesFed =   "You have saved enough citizens!";

char *cantDrink = "Not enough access. Access denied!";
char *drankFUEL = "Access allowed, reactor initiated!";

char *wonGame   = "You have saved the galaxy and thus are remembered by the people!";

char *wonGame2 = "Of course the invading force has not been defeated yet, there will be more fights.";

char *CITIZENLine = "They are everywhere!";

char *METEORLine = "save me! save me!";

char *creatureLine1 = "They are everywhere!";
char *creatureLine2 = "Come to save me!";





int get_action(GameInputs inputs)
{

    //to signal next part of quest
    if (Player.METEORCount == MISSILE_COUNT) {
        wait_ms(800);
        speech(Details);
        Player.METEORCount++;
         draw_lower_status(0,5,1);
        questSwitch = 1;
        return GO_DOWN;
    }

    if(Player.creatureCount == CREATURE) {
        wait_ms(800);
        speech(creaturesFed);
        Player.creatureCount++;
        draw_lower_status(0,5,1);
        questSwitch = 2;
        return GO_DOWN;
    }

    //for narrator at beginning
    if (narratorSwitch == 1) {
        wait_ms(800);
        speech(narrator1);
        narratorSwitch = 0;
        draw_lower_status(0, 0, 0);
        return GO_DOWN;
    }
    if(creatureSwitch) {
        draw_lower_status(5,1,0);
        creatureSwitch = 0;
    }

    if (FUELSwitch == 2) {
        wait_ms(800);
        
        speech(wonGame2);
        
        init_second_map();
        FUELSwitch = 3;
        wait_ms(800);
        return END_GAME;
    }

    // for defense mode
    if (!inputs.b2) 
    {
        weapon_pressed = !weapon_pressed;
        if (weapon_pressed) {
            myTTS.speakf("S");//Speak command starts with "S"
            myTTS.speakf("Activating defense system");  // Send the desired string to convert to speech
            myTTS.speakf("\r"); //marks end of speak command
            uLCD.circle(64, 64, 30, BLUE);
        }
        wait_ms(500);
        init_second_map();
        set_active_map(1);
        Player.x =2;
        Player.y = 3;
        Player.METEORCount = 0;
        Player.creatureCount = 0;
        // Initial drawing
        draw_game(true);
    }

    //for action button
    if (!inputs.b1) return ACTION_BUTTON;
    if (!inputs.b3) return FIRE;
    if (inputs.ay >= 0.43) return GO_DOWN;
    if (inputs.ay < -0.55) return GO_UP;
    if (inputs.ax < -0.50)  return GO_RIGHT;
    if (inputs.ax >= 0.50) return GO_LEFT;

    else return NO_ACTION;
}

/**
 * Update the game state based on the user action. For example, if the user
 * requests GO_UP, then this function should determine if that is possible by
 * consulting the map, and update the Player position accordingly.
 *
 * Return values are defined below. FULL_DRAW indicates that for this frame,
 * draw_game should not optimize drawing and should draw every tile, even if
 * the player has not moved.
 */
#define NO_RESULT 0
#define GAME_OVER 4
#define FULL_DRAW 2
#define L 11
#define R 12
#define U 13
#define D 14
int update_game(int action)
{
    // Save player previous location before updating
    Player.px = Player.x;
    Player.py = Player.y;
    Player.prevMETEORCount = Player.METEORCount;
    Player.prevcreatureCount = Player.creatureCount;
    if (Player.METEORCount  >= MISSILE_COUNT) METEORSwitch = 1;
    if(Player.creatureCount == CREATURE) creatureSwitch = 0;

    // Do different things based on the each action.
    // You can define functions like "go_up()" that get called for each case.
    switch(action) {
        case GO_UP:
            if (go_up(Player.px,Player.py)) return FULL_DRAW;
            else break;
        case GO_LEFT:
            if (go_left(Player.px,Player.py)) return FULL_DRAW;
            else break;
        case GO_DOWN:
            if (go_down(Player.px,Player.py)) return FULL_DRAW;
            else break;
        case GO_RIGHT:
            if (go_right(Player.px,Player.py)) return FULL_DRAW;
            else break;
        case ACTION_BUTTON:
            if(get_surrounding_object(Player.x,Player.y))return FULL_DRAW;
            else break;
        case MENU_BUTTON:
            break;
        case FIRE:
            fire(Player.x, Player.y);
            return FULL_DRAW;
        case END_GAME:
            return GAME_OVER;
        default:
            break;
    }
    return NO_RESULT;
}

int get_surrounding_object(int x, int y)
{
    MapItem *item1 = get_east(x+0.5, y); //get item to right
    MapItem *item2 = get_east(x+0.5,y-1);
    MapItem *item3 = get_west(x-1, y); //get item to left
    MapItem *item4 = get_west(x-1,y-1);
    MapItem *item5 = get_north(x-1, y-1); //get item to north
    MapItem *item6 = get_north(x, y-1);
    MapItem *item7 = get_north(x-1, y);
    MapItem *item8 = get_south(x, y+0.5); //get item to south
    MapItem *item9 = get_south(x-1, y+0.5);


    //check types
    //CITIZEN
    if (item1->type == CITIZEN || item2->type == CITIZEN || item3->type == CITIZEN || item4->type == CITIZEN \
            ||item5->type == CITIZEN || item6->type == CITIZEN || item7->type == CITIZEN || item8->type == CITIZEN \
            || item9->type == CITIZEN) {
        speech(CITIZENLine);
        return 1;
    }
    //SURVIVOR
    if (item1->type == SURVIVOR || item2->type == SURVIVOR || item3->type == SURVIVOR || item4->type == SURVIVOR \
            ||item5->type == SURVIVOR || item6->type == SURVIVOR || item7->type == SURVIVOR || item8->type == SURVIVOR \
            || item9->type == SURVIVOR) {
        if (questSwitch == 0) {
            speech(lineStartQuest);
            narratorSwitch = 1;
        }

        else if(questSwitch == 1) {
            speech(questSection2);
            creatureSwitch = 1;
        } else if (questSwitch == 2) {
            speech(questSection3);
            draw_lower_status(0,3,0);
            FUELSwitch = 1;
        } else if (questSwitch == 3) {
            speech(wonGame);
            FUELSwitch = 2;
        }
        return 1;
    }


    if (item1->type == METEOR || item2->type == METEOR || item3->type == METEOR || item4->type == METEOR \
            ||item5->type == METEOR || item6->type == METEOR || item7->type == METEOR || item8->type == METEOR \
            || item9->type == METEOR) {

        if(Player.METEORCount < MISSILE_COUNT) {
            map_erase(x+1.5,y);
            map_erase(x+1.5,y-1);
            map_erase(x-2,y-1);
            map_erase(x-2,y);
            map_erase(x-1,y-1);
            map_erase(x-1,y-2);
            map_erase(x,y-2);
            map_erase(x+1.5,y);
            map_erase(x,y+1.5);
            map_erase(x,y+1.5);
            map_erase(x-1,y+1.5);

            speech(METEORLine);
            Player.METEORCount++;

            return 1;
        } else {
            speech(Details2);
            return 1;
        }

    }


    if (item1->type == CREATURE || item2->type == CREATURE || item3->type == CREATURE || item4->type == CREATURE \
            ||item5->type == CREATURE || item6->type == CREATURE || item7->type == CREATURE || item8->type == CREATURE \
            || item9->type == CREATURE) {

        if(questSwitch == 1) {

            if (!strcmp((char*)item1->data, "creature1") || !strcmp((char*)item2->data, "creature1")|| !strcmp((char*)item3->data, "creature1") || !strcmp((char*)item4->data, "creature1") \
                    ||!strcmp((char*)item5->data, "creature1") || !strcmp((char*)item6->data, "creature1")||!strcmp((char*)item7->data, "creature1")|| !strcmp((char*)item8->data, "creature1") \
                    || !strcmp((char*)item9->data, "creature1")) {
                speech(creatureLine2);
                Player.creatureCount++;

                map_erase(x+1.5,y);
                map_erase(x+1.5,y-1);
                map_erase(x-2,y-1);
                map_erase(x-2,y);
                map_erase(x-1,y-1);
                map_erase(x-1,y-2);
                map_erase(x,y-2);
                map_erase(x+1.5,y);
                map_erase(x,y+1.5);
                map_erase(x,y+1.5);
                map_erase(x-1,y+1.5);

                return 1;
            } else {
                speech(creatureLine1);
                Player.creatureCount++;

                map_erase(x+1.5,y);
                map_erase(x+1.5,y-1);
                map_erase(x-2,y-1);
                map_erase(x-2,y);
                map_erase(x-1,y-1);
                map_erase(x-1,y-2);
                map_erase(x,y-2);
                map_erase(x+1.5,y);
                map_erase(x,y+1.5);
                map_erase(x,y+1.5);
                map_erase(x-1,y+1.5);

                return 1;
            }

        } else speech(creaturesFed);
    }



    ////for FUEL
    if (item1->type == FUEL || item2->type == FUEL || item3->type == FUEL || item4->type == FUEL \
            ||item5->type == FUEL || item6->type == FUEL || item7->type == FUEL || item8->type == FUEL \
            || item9->type == FUEL) {
        if(Player.METEORCount  >= 5)

        {
            speech(drankFUEL);
            questSwitch = 3;
            map_erase(x+1.5,y);
            map_erase(x+1.5,y-1);
            map_erase(x-2,y-1);
            map_erase(x-2,y);
            map_erase(x-1,y-1);
            map_erase(x-1,y-2);
            map_erase(x,y-2);
            map_erase(x+1.5,y);
            map_erase(x,y+1.5);
            map_erase(x,y+1.5);
            map_erase(x-1,y+1.5);
            return 1;

        } else {
            speech(cantDrink);
            return 1;
        }
    }
    return 0;
}

int fire(int x, int y)
{
    int range = 64;
    uLCD.filled_circle(64, 64, 3, BLUE);
    while (range < 120) {
        uLCD.filled_circle(range,64, 3, BLUE);
        range++;
    }
    myTTS.speakf("S");//Speak command starts with "S"
    myTTS.speakf("Fire, Fire");  // Send the desired string to convert to speech
    myTTS.speakf("\r"); //marks end of speak command
    return 1;
}    

int go_right(int x, int y)
{
    MapItem *item = get_east(x+0.5, y); //get item to right
    MapItem *item2 = get_east(x+0.5,y-1);
    if ( (item->walkable && item2->walkable) || weapon_pressed) { // check if walkable
        Player.x++;
        return 1;
    } else return 0;
}

int go_left(int x, int y)
{
    MapItem *item = get_west(x-1, y); //get item to left
    MapItem *item2 = get_west(x-1,y-1);
    if ( (item->walkable && item2->walkable) || weapon_pressed)  { // check if walkable
        Player.x--;
        return 1;
    } else return 0;
}

int go_up(int x, int y)
{
    MapItem *item = get_north(x-1, y-1); //get item to north
    MapItem *item2 = get_north(x, y-1);
    MapItem *item3 = get_north(x-1, y);
    if ((item->walkable && item2->walkable && item3->walkable) || weapon_pressed) { // check if walkable
        Player.y--;
        return 1;
    } else return 0;
}

int go_down(int x, int y)
{
    MapItem *item = get_south(x, y+0.5); //get item to south
    MapItem *item2 = get_south(x-1, y+0.5);
    if ((item->walkable && item2->walkable) || weapon_pressed) { // check if walkable
        Player.y++;
        return 1;
    } else return 0;
}



/**
 * Entry point for frame drawing. This should be called once per iteration of
 * the game loop. This draws all tiles on the screen, followed by the status
 * bars. Unless init is nonzero, this function will optimize drawing by only
 * drawing tiles that have changed from the previous frame.
 */

void draw_game(int init)
{
    //game over
    if (init == 4) {
        uLCD.filled_rectangle(0,0,255,255,BLACK);
        uLCD.locate(2,4);
        uLCD.textbackground_color(BLACK);
        uLCD.text_width(2);
        uLCD.text_height(2);
        uLCD.color(0x00FFDE);
        uLCD.printf("Protector of the Galaxy, the Star Alliance Will Forever Remember You!");
        uLCD.locate(1,5);
        uLCD.text_height(2);
        uLCD.text_width(1);
        uLCD.color(WHITE);
        uLCD.printf("End of Game");
        wait(100000000000000);
    }

    // Draw game border first
    if(init)draw_border();
    
                
    // Iterate over all visible map tiles
    for (int i = -5; i <= 5; i++) { // Iterate over columns of tiles
        for (int j = -4; j <= 4; j++) { // Iterate over one column of tiles
            // Here, we have a given (i,j)

            // Compute the current map (x,y) of this tile
            int x = i + Player.x;
            int y = j + Player.y;

            // Compute the previous map (px, py) of this tile
            int px = i + Player.px;
            int py = j + Player.py;

            // Compute u,v coordinates for drawing
            int u = (i+5)*11 + 3;
            int v = (j+4)*11 + 15;

            // Figure out what to draw
            DrawFunc draw = NULL;
            if (init && i == 0 && j == 0) { // draw player upon init
                draw_player(u, v, Player.has_key);
                continue;
            } else if (x >= 0 && y >= 0 && x < map_width() && y < map_height()) { // Current (i,j) in the map
                MapItem* curr_item = get_here(x, y);
                MapItem* prev_item = get_here(px, py);
                if (init || curr_item != prev_item) { // Only draw if they're different
                    if (curr_item) { // There's something here! Draw it
                        draw = curr_item->draw;
                    } else { // There used to be something, but now there isn't
                        draw = draw_nothing;
                    }
                }
                
            } else if (init) { // If doing a full draw, but we're out of bounds, draw the blocks.
                draw = draw_block;
            }

            // Actually draw the tile
            if (draw) draw(u, v);
        }
    }

    // draw the updated coords only if player's position changed
    if ( (Player.x!=Player.px) || (Player.py != Player.y) || (Player.METEORCount != Player.prevMETEORCount)) {
        draw_upper_status(Player.x,Player.y,Player.METEORCount,METEORSwitch);
    }
    //quest status on bottom
    if ((Player.prevMETEORCount!= Player.METEORCount) || (Player.prevcreatureCount != Player.creatureCount)) \
        draw_lower_status(Player.METEORCount, questSwitch, Player.creatureCount);
    // draw player orientation
    if (Player.px < Player.x) {
        draw_player(59, 59, Player.has_key);
    } else if (Player.px > Player.x) {
        draw_player_LEFT(59, 59, Player.has_key);
        myTTS.speakf("S");//Speak command starts with "S"
        myTTS.speakf("Over G");  // Send the desired string to convert to speech
        myTTS.speakf("\r"); //marks end of speak command
    } 
    if (Player.py > Player.y) {
        draw_player_UP(59, 59, Player.has_key);
        myTTS.speakf("S");//Speak command starts with "S"
        myTTS.speakf("Over G");  // Send the desired string to convert to speech
        myTTS.speakf("\r"); //marks end of speak command
    } else if (Player.py < Player.y){
        draw_player_DOWN(59, 59, Player.has_key);
        myTTS.speakf("S");//Speak command starts with "S"
        myTTS.speakf("Over G");  // Send the desired string to convert to speech
        myTTS.speakf("\r"); //marks end of speak command
    }
    
}


/**
 * Initialize the main world map. Add blocks around the edges, interior chambers,
 * and plants in the background so you can see motion.
 */

void init_main_map()
{

    draw_intro();


    uLCD.text_width(1);
    uLCD.text_height(1);
    Map* map = set_active_map(0);

    for( int i = map_width() + 4; i < map_area(); i += 60) {
        add_meteor(i % map_width(), i / map_width());
    }


    //Add CITIZEN NPC :)

    add_citizen(3,10);
    add_citizen(10,25);
    add_citizen(6,19);
    add_citizen(26,21);
    add_citizen(30,21);
    add_citizen(40,28);

    add_survivor(6,5);
    add_survivor(36,36);

    add_fuel(35,30);
    add_fuel(36,30);
    add_fuel(34,30);

    add_creature1(12,12);
    add_creature2(12,30);
    add_creature1(6,17);
    add_creature2(5,27);
    add_creature1(10,37);
    add_creature1(15,30);
    add_creature2(30,40);
    add_creature1(30,3);
    add_creature2(29,51);
    add_creature1(18,16);


    add_block(0,              0,              HORIZONTAL, map_width());
    add_block(0,              map_height()-1, HORIZONTAL, map_width());
    add_block(0,              0,              VERTICAL,   map_height());
    add_block(map_width()-1,  0,              VERTICAL,   map_height());
    pc.printf("blocks done!\r\n");


    //draw little room
    add_block2(30,            40,             HORIZONTAL, 11);
    add_block2(30,            30,             VERTICAL,   10);
    add_block2(40,            30,             VERTICAL,   10);
    add_block2(30,            30,             HORIZONTAL,  4);
    add_block2(37,            30,             HORIZONTAL,  4);


    print_map();

}


void init_second_map()
{

    draw_intro();


    uLCD.text_width(1);
    uLCD.text_height(1);
    Map* map = set_active_map(1);

    for( int i = map_width() + 4; i < map_area(); i += 60) {
        add_meteor(i % map_width(), i / map_width());
    }

    add_citizen(3,10);
    add_citizen(10,25);
    add_citizen(6,19);

    add_survivor(6,5);
    add_survivor(36,36);

    add_fuel(35,30);
    add_fuel(36,30);
    add_fuel(34,30);

    add_creature1(12,12);
    add_creature2(12,30);
    add_creature1(6,17);
    add_creature2(5,27);
    add_creature1(10,37);

    add_block(0,              0,              HORIZONTAL, map_width());
    add_block(0,              map_height()-1, HORIZONTAL, map_width());
    add_block(0,              0,              VERTICAL,   map_height());
    add_block(map_width()-1,  0,              VERTICAL,   map_height());
    pc.printf("blocks done!\r\n");


    //draw little room
    add_block2(30,            40,             HORIZONTAL, 11);
    add_block2(30,            30,             VERTICAL,   10);
    add_block2(40,            30,             VERTICAL, 10);
    add_block2(30,            30,             HORIZONTAL,  4);
    add_block2(37,            30,             HORIZONTAL,  4);


    print_map();

}


/**
 * Program entry point! This is where it all begins.
 * This function orchestrates all the parts of the game. Most of your
 * implementation should be elsewhere - this holds the game loop, and should
 * read like a road map for the rest of the code.
 */
int main()
{
    // First things first: initialize hardware
    ASSERT_P(hardware_init() == ERROR_NONE, "Hardware init failed!");

    // Initialize the maps
    draw_border();
    maps_init();
    init_main_map();
    draw_upper_status(5,5,0,0);
    draw_lower_status(0,5,1);
    uLCD.filled_circle(120,121,4,BLACK);
    uLCD.filled_circle(120,121,3,0x2EFF1F);



    // Initialize game state
    set_active_map(0);
    Player.x =2;
    Player.y = 3;
    Player.METEORCount = 0;
    Player.creatureCount = 0;

    // Initial drawing
    draw_game(true);
    myTTS.volume(2); //max volume
    myTTS.voice(3);
    // Main game loop
    while(1) {
        // Timer to measure game update speed
        Timer t;
        t.start();

        // Actually do the game update:
        // 1. Read inputs
        in = read_inputs();

        //draw_img(29,20,test);


        // 2. Determine action (get_action)
        action = get_action(in);


        // 3. Update game (update_game)
        update = update_game(action);
        // 3b. Check for game over

        // 4. Draw frame (draw_game)
        draw_game(update);

        // 5. Frame delay
        t.stop();
        int dt = t.read_ms();//change back to 100
        if (dt < 100) wait_ms(100 - dt);
    }
}


//draws start menu
void draw_intro()
{
    if (startScreen == 1) {
        startScreen = 0;
        in = read_inputs();
        int i;
        int count = 0;
        uLCD.textbackground_color(BLACK);
        char *startLine = "Saving the Galaxy";
        char *top = "----------------";
        char *LowerLine = "Be the Hero!";


        //if top button is not pressed
        while (in.b1) {
            in = read_inputs();
            //print out first line of start screen
            if (count == 0) {
                uLCD.locate(0,0);
                uLCD.color(RED);
                uLCD.printf(top);
                uLCD.locate(1,2);
                for (i = 0; i<8; ++i) {
                    uLCD.color(0xFFFF00);

                    uLCD.text_width(2);
                    uLCD.text_height(2);

                    uLCD.printf("%c", *startLine);
                    wait_ms(10);
                    startLine++;
                }
            }

            //print out second line of start screen
            if (count == 1) {
                uLCD.locate(1,3);
                for (i = 9; i<21; ++i) {
                    if (i == 9) uLCD.text_bold(TEXTBOLD);



                    uLCD.text_italic(TEXTITALIC);
                    

                    uLCD.text_width(1);
                    uLCD.text_height(2);

                    uLCD.printf("%c", *startLine);
                    wait_ms(150);
                    startLine++;
                
                }
            }
            //print out "TO"
            if (count == 2) {
                uLCD.locate(7,4);
                for (i = 22; i<26; ++i) {

                    uLCD.text_bold(TEXTBOLD);
                    if(i<22)  uLCD.color(0x2EFF1F);
                    else uLCD.color(BLUE);

                    uLCD.text_width(1);
                    uLCD.text_height(2);

                    uLCD.printf("%c", *startLine);
                    wait_ms(50);
                    startLine++;
                }
            }

            if (count == 3) {
                uLCD.locate(0,6);
                for (i = 26; i<37; ++i) {
                    if(i == 26) {
                        uLCD.text_height(5);
                        uLCD.text_width(2);
                        uLCD.color(0xE5B149);
                    } else if (i< 34) {
                        uLCD.set_font(FONT_7X8);
                        if (i!=33)uLCD.text_italic(TEXTITALIC);
                        uLCD.text_width(2);
                        
                        uLCD.color(0x00FF00);
                    } else {
                        uLCD.text_width(1);
                        uLCD.color(0X00FF00);

                    }
                    uLCD.printf("%c", *startLine);
                    wait_ms(50);
                    startLine++;
                }

                //print name

                uLCD.text_height(1);
                uLCD.text_width(1);
                uLCD.locate(3,15);
                uLCD.color(0x3A36B0);
                uLCD.printf(LowerLine);

            }
            count++;
            in = read_inputs();
        }
    }
}